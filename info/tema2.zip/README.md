# **Tema 2 - Compresia imaginilor utilizând arbori**

>În cadrul acestei teme, am implementat un algoritm de compresie a imaginilor
în format `PPM`. Prin intermediul arborilor cuaternari, poate fi efectuată
compresia și decompresia imaginilor, cu scopul de a le reprezenta folosind cât
mai puțină informație.

Pentru a realiza cerințele date au fost create anumite structuri, fiind
declarate în fișierul `"structs.h"`. Structura `"img_data"` conține dimensiunile
imaginii date, formatul fișierului, intensitatea maxima a unei culori și
matricea formată din toți pixelii imaginii. Structura `"QuadTreeNode"` permite
crearea unui arbore cuaternar care conține urmatoarele date: valorile canalelor
RGB sub formă de structură `"pixel"`, coordonatele `x` și `y` corespunzătoare
primului pixel a submatricei nodului, dimensiunea submatricei reprezentate de
nodul dat, un vector de noduri descendente și faptul dacă nodul dat este frunză
sau nu.

Funcțiile necesare efectuării tuturor cerințelor au fost scrise în fișierele de
tip header `"utils.h"`, `"QuadTree.h"` și `"Queue.h"`.

## **CUPRINS**
---
1. [Funcția "main"](#funcția-main)
2. [Funcțiile din fișierul "utils.h"](#funcțiile-din-fișierul-utilsh)
3. [Funcțiile arborelui cuaternar](#funcțiile-arborelui-cuaternar)
4. [Funcțiile cozii](#funcțiile-cozii)
5. [Funcțiile necesare realizării cerinței 1](#funcțiile-necesare-realizării-cerinței-1)
6. [Funcțiile necesare realizării cerinței 2](#funcțiile-necesare-realizării-cerinței-2)
7. [Funcțiile necesare realizării cerinței 3](#funcțiile-necesare-realizării-cerinței-3)

## **FUNCȚIA "MAIN"**
---
**1.** În cazul fiecărei cerințe, se definesc 2 variabile de tip `FILE*`
(fin, fout) pentru a accesa fișierele:
- `fin` corespunde fișierului de intrare, din care se citește informația
necesară, care urmeaza a fi procesată;
- `fout` corespunde fișierului de ieșire, în care se scriu rezultatele
efectuării cerinței date;

**2.** Pentru cerințele 1 și 2, se citește și se stochează informația necesară
în variabilele `image_data` și `factor`, iar pentru cerința 3, se va utiliza
doar variabila `image_data` pentru stocarea informației;

**3.** În dependență de primul argument al executabilului în linia de comandă,
se apelează funcțiile:
- `"task1"` - funcție care realizează cerința 1;
- `"task2"` - funcție care realizează cerința 2;
- `"task3"` - funcție care realizează cerința 3;

**4.** Se eliberează memoria alocată dinamic pentru datele imaginii;

**5.** Se închid fișierele "fin" și "fout".

## **FUNCȚIILE DIN FIȘIERUL "utils.h"**
---
- `"read_image_data"` - funcție care procesează conținutul unei imagini și
returnează un pointer către o structură ce conține datele imaginii;
- `"read_compressed_image_data"` - funcție care procesează conținutul unei
fișier binar ce conține informația despre o imagine și returnează un pointer
către o structură ce conține datele imaginii;
- `"write_image_data"` - funcție care scrie fișierul binar pe baza arborelui
cuaternar creat în urma citirii fișierului comprimat;
- `"mean_pixel"` - calculează culoarea medie a unei submatrici și returnează
o structura de tip `"pixel"` ce conține această culoare;
- `"colors_mean"` - calculează media culorilor RGB a unei submatrici conform
formulei indicate în cerință;
- `"free_memory"` - funcție care elibereaza memoria alocată dinamic pentru
datele unei imagini.

## **FUNCȚIILE ARBORELUI CUATERNAR**
---
- `"createTree"` - creează un arbore;
- `"insert_node"` - insereaza un nou nod în arbore;
- `"level_order_insert"` - insereaza un nou nod în arbore, în ordinea
parcurgerii pe nivel;
- `"insert_node_details"` - se introduc datele unui nod în funcție de tipul
acestuia (dacă este frunză sau nu);
- `"height"` - returnează înălțimea unui arbore;
- `"write_current_level"` - scrie în fișierul binar datele nodurilor de pe un
anumit nivel;
- `"write_all_levels"` - scrie în fișierul binar datele tuturor nodurilor
dintr-un arbore cuaternar în ordine pe nivel;
- `"leaves_number"` - returnează numărul de frunze ale unui arbore;
- `"get_leaves"` - funcție care salvează pointerii nodurilor frunză într-un vector;
- `"largest_undivided_area"` - funcție care returnează dimensiunea celei mai
mari suprafețe nedivizate (o suprafață nedivizată este reprezentată de o frunză a arborelui);
- `"freeTree"` - funcție care eliberează memoria alocată dinamic pentru arborele cuaternar;

## **FUNCȚIILE COZII**
---
- `"createQueue"` - creează o coadă;
- `"isQueueEmpty"` - determină dacă coada este goală sau nu;
- `"enqueue"` - introduce un nou element în coadă;
- `"dequeue"` - extrage un element din coadă;
- `"front"` - returnează valoarea primului element din coadă;
- `"destroyQueue"` - eliberează memoria ocupată de coada alocată dinamic;

## **FUNCȚIILE NECESARE REALIZĂRII CERINȚEI 1**
---
- **`"read_image_data"`**
- **`"insert_node"`**
- **`"height"`**
- **`"leaves_number"`**
- **`"largest_undivided_area"`**
- **`"freeTree"`**
- **`"free_memory"`**

## **FUNCȚIILE NECESARE REALIZĂRII CERINȚEI 2**
---
- **`"read_image_data"`**
- **`"insert_node"`**
- **`"write_all_levels"`**
- **`"freeTree"`**
- **`"free_memory"`**

## **FUNCȚIILE NECESARE REALIZĂRII CERINȚEI 3**
---
- **`"read_compressed_image_data"`**
- **`"write_image_data"`**
- **`"free_memory"`**

​

    © Racovcen Laurențiu
